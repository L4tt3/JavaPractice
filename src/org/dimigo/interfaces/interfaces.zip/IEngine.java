package org.dimigo.interfaces;

public interface IEngine {

    void startEngine();
    void stopEngine();
}
